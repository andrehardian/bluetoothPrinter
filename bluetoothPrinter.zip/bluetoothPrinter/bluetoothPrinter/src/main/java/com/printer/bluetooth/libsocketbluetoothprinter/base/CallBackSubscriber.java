package com.printer.bluetooth.libsocketbluetoothprinter.base;

public interface CallBackSubscriber {
    void onServiceFinish();
}
