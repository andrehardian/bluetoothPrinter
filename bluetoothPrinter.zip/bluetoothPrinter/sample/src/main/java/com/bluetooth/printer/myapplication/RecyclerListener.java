package com.bluetooth.printer.myapplication;


import java.util.ArrayList;

public interface RecyclerListener {
    void onItemClick(Object o);

    void notifyData(int position);

}
