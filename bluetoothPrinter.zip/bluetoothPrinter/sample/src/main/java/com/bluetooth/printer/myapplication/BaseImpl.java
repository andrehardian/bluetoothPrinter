package com.bluetooth.printer.myapplication;

public class BaseImpl {
}
